import requests

# URL de la API
url = "http://127.0.0.1:8001/predict/"

# Ruta de la imagen que deseas enviar
image_path = "../arcgis-survey-images/Roya Purpura/fotografia-20240914-130154_OID1570_ATT1570.jpg"

# Abrir la imagen en modo binario
with open(image_path, "rb") as image_file:
    # Enviar la petición POST con la imagen
    response = requests.post(url, files={"file": image_file})

# Comprobar la respuesta
if response.status_code == 200:
    print("Predicción:", response.json())
else:
    print("Error al hacer la petición:", response.status_code, response.text)
